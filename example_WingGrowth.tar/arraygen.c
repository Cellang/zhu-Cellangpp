#include <stdio.h>
#include <stdlib.h>
/*#include "my_rand.h"*/

int main(int argc, char *argv[]) {
	int dim=120, x, y, type;
	printf("0\n") ; 


	for (x=0 ;x<dim+4 ;x++)
	for (y=0 ;y<dim+4 ;y++)  { 
		if (x==0 || x==dim+1 || y==0 || y==dim+1)
			type = 0;
		else 
			type = 0;	/* Previously set to 1, now to conveniently judge if a unit is empty, background type=0 */   
		printf("[%d,%d]=%d\n",x, y, type) ;  
	}
	return 0 ;
}
