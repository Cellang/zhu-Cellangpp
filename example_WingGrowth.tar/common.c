/* common.inc
   Copyright (C) 1998  J Dana Eckart
   Accessed in makefile. 
 */

/* The following variables are the lower and upper bounds of the
   dimensions to display.
*/
extern int dim_given, range_dim_1_index, range_dim_2_index, range_dim_3_index;
extern int lower[], upper[];

void bad_arith(int exit_status) {
        fprintf(stderr, "%s: Division by zero (0).\n", command);
	fflush((FILE*) NULL);
        exit_signaled(1);
}

long int mydiv(long int a, long int b) {
        if (a == 0) return 0;
        else {
                long int quotient = labs(a)/labs(b);
                return (((a <= 0 && b <= 0) || (a >= 0 && b >= 0)) ?
                                quotient : -quotient);
        }
}

long int mymod(long int a, long int b) {
        return (a - b * mydiv(a, b));
}

static long int last = 10;

void set_seed(long int seed) {
	last = seed;
}

long int myrandom(void) {
	return last = (1909 * last + 221571) % 65563;
}

float myfrandom(void) {
	last = (1909 * last + 221571) % 65563;
	return ((float) last)/65563.0;
}

/*=============================uni.inc=============================*/
void init_display(void) {
	dim_given = 0;

	range_dim_1_index = 0;
	range_dim_2_index = 1;
	/*range_dim_3_index = 2;*/

#if DIMS >= 1
	lower[0] = 0;
	upper[0] = DIM_1_SIZE-1;
#endif
#if DIMS >= 2
	lower[1] = 0;
	upper[1] = DIM_2_SIZE-1;
#endif
#if DIMS >= 3
	lower[2] = 0;
	upper[2] = DIM_3_SIZE-1;
#endif
}

