int Wgff[DIM_1_SIZE][DIM_2_SIZE];
int Ntmff[DIM_1_SIZE][DIM_2_SIZE];
int Xff[DIM_1_SIZE][DIM_2_SIZE];
int Ds_Pff[DIM_1_SIZE][DIM_2_SIZE];
int Ds_Dff[DIM_1_SIZE][DIM_2_SIZE];
int Ft_Pff[DIM_1_SIZE][DIM_2_SIZE];
int Ft_Dff[DIM_1_SIZE][DIM_2_SIZE];
int FtF7_Pff[DIM_1_SIZE][DIM_2_SIZE];
int FtF7_Dff[DIM_1_SIZE][DIM_2_SIZE];
int DDs_Pff[DIM_1_SIZE][DIM_2_SIZE];
int DDs_Dff[DIM_1_SIZE][DIM_2_SIZE];
#define neqn 21
float xl=0.0, xu=1.0, hmin=0.0005, abserr=0.00001, relerr=0.00001; 	/* tf=4.0 not required */

int dim_1_ode, dim_2_ode;
int eqnerr, incre, neqni;
int eval;
/* float h=0.001, t0=0.0, t1=0.0; -- t0 is in zhux11 even without OPDE */
float u0[DIM_1_SIZE][DIM_2_SIZE][neqn+1],  u[DIM_1_SIZE][DIM_1_SIZE][neqn+1];
float u0x[DIM_1_SIZE][DIM_2_SIZE][neqn+1],  ux[DIM_1_SIZE][DIM_1_SIZE][neqn+1];
float u0y[DIM_1_SIZE][DIM_2_SIZE][neqn+1],  uy[DIM_1_SIZE][DIM_1_SIZE][neqn+1];
float dudt0[DIM_1_SIZE][DIM_2_SIZE][neqn+1], dudt[DIM_1_SIZE][DIM_2_SIZE][neqn+1], err[DIM_1_SIZE][DIM_2_SIZE][neqn+1];
float u2[DIM_1_SIZE][DIM_2_SIZE][neqn+1], u4[DIM_1_SIZE][DIM_2_SIZE][neqn+1], u5[DIM_1_SIZE][DIM_2_SIZE][neqn+1];
float k1[DIM_1_SIZE][DIM_2_SIZE][neqn+1], k2[DIM_1_SIZE][DIM_2_SIZE][neqn+1], k3[DIM_1_SIZE][DIM_2_SIZE][neqn+1];
float k4[DIM_1_SIZE][DIM_2_SIZE][neqn+1], k5[DIM_1_SIZE][DIM_2_SIZE][neqn+1];
void derv(int dim1, int dim2);
void initial(int dim1, int dim2);
void boundary(void);
void dsx(int);
void dsy(int);
float dssx(float, int);
float dssy(float, int);
float del(float, int);
float Ha(float, float, float);
float Hr(float, float, float);
float Ub(float, float, float);
float dx = 0.2 /* if 1.0/(DIM_1_SIZE-2) is used to control dx and dy, running is very slow. */;
float dy = 0.2;
